#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys, os, socket
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import *

class ModernCircle(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.percent = 0
        self.setFixedSize(200, 200)

    def setPercent(self, val):
        self.percent = max(0, min(100, val))
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        cx, cy = 100, 100
        radius = 90
        pen_width = 16

        p.setPen(QPen(QColor(255,255,255,60) if self.window().theme=="Dark" else QColor(0,0,0,60), pen_width))
        p.drawArc(cx-radius, cy-radius, radius*2, radius*2, 0, 360*16)

        if self.percent > 0:
            grad = QConicalGradient(cx, cy, 90)
            pct = self.percent
            if self.window().theme == "Light":
                yellow1 = QColor(255, 200, 0)
                yellow2 = QColor(255, 220, 50)
            else:
                yellow1 = QColor(255, 255, 0)
                yellow2 = QColor(255, 255, 100)

            if pct <= 25:
                t = pct / 25
                color = QColor(
                    int(yellow1.red()*(1-t) + yellow2.red()*t),
                    int(yellow1.green()*(1-t) + yellow2.green()*t),
                    int(yellow1.blue()*(1-t) + yellow2.blue()*t)
                )
            elif pct <= 50:
                t = (pct-25)/25
                color = QColor(int(180*(1-t)+128*t), int(240*(1-t)+255*t), 0)
            elif pct <= 75:
                t = (pct-50)/25
                color = QColor(int(0*(1-t)+0*t), int(128*(1-t)+200*t), 0)
            else:
                t = (pct-75)/25
                color = QColor(int(255*(1-t)+200*t), int(0*(1-t)+50*t), 0)

            grad.setColorAt(0, color)
            grad.setColorAt(1, color)
            p.setPen(QPen(grad, pen_width, Qt.SolidLine, Qt.RoundCap))
            p.drawArc(cx-radius, cy-radius, radius*2, radius*2, 90*16, int(-pct*3.6*16))

        p.setFont(QFont("Arial", 36, QFont.Bold))
        p.setPen(QColor("#ffffff") if self.window().theme=="Dark" else QColor("#000000"))
        p.drawText(self.rect(), Qt.AlignCenter, f"{int(self.percent)}%")

class TurnOff_v2(QWidget):
    def __init__(self):
        super().__init__()
        self.theme = "Dark"
        self.total = self.remain = 0
        self.is_paused = False
        self.action = "poweroff"

        self.setWindowTitle("TurnOff_v2")
        self.setFixedSize(400, 620)
        self.setWindowIcon(QIcon.fromTheme("system-shutdown"))

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)

        self.ui()
        self.style()

    def ui(self):
        v = QVBoxLayout(self)
        v.setContentsMargins(20,20,20,20)
        v.setSpacing(15)

        self.focus_placeholder = QLabel()
        self.focus_placeholder.setFixedSize(0,0)
        self.focus_placeholder.setFocusPolicy(Qt.StrongFocus)
        v.addWidget(self.focus_placeholder)

        hbox = QHBoxLayout()
        self.h = QLineEdit()
        self.h.setPlaceholderText("Saat")
        self.h.setFixedWidth(90)
        self.h.setAlignment(Qt.AlignCenter)
        self.h.setValidator(QIntValidator(0,23))

        self.m = QLineEdit()
        self.m.setPlaceholderText("Dakika")
        self.m.setFixedWidth(90)
        self.m.setAlignment(Qt.AlignCenter)
        self.m.setValidator(QIntValidator(0,59))

        hbox.addStretch()
        hbox.addWidget(self.h)
        hbox.addWidget(QLabel(" : "))
        hbox.addWidget(self.m)
        hbox.addStretch()
        v.addLayout(hbox)

        self.circle = ModernCircle(self)
        v.addWidget(self.circle, alignment=Qt.AlignCenter)

        self.time = QLabel("00:00:00")
        self.time.setFont(QFont("Arial", 36, QFont.Bold))
        self.time.setAlignment(Qt.AlignCenter)
        v.addWidget(self.time)

        btns = QGridLayout()
        btns.setSpacing(12)

        self.btn_start = QPushButton("Kapat")
        self.btn_stop  = QPushButton("Beklet")
        self.btn_cancel = QPushButton("İptal")
        self.btn_restart = QPushButton("Yeniden Başlat")

        for b in (self.btn_start, self.btn_stop, self.btn_cancel, self.btn_restart):
            b.setFixedSize(140, 70)
            b.setFont(QFont("Arial", 13, QFont.Bold))

        v.addStretch()

        self.btn_start.clicked.connect(lambda: self.start(action="poweroff"))
        self.btn_stop.clicked.connect(self.toggle_pause)
        self.btn_cancel.clicked.connect(self.cancel)
        self.btn_restart.clicked.connect(lambda: self.start(action="reboot"))

        btns.addWidget(self.btn_start, 0, 0)
        btns.addWidget(self.btn_stop, 0, 1)
        btns.addWidget(self.btn_cancel, 1, 0)
        btns.addWidget(self.btn_restart, 1, 1)
        v.addLayout(btns)

        self.status = QLabel("Hazır")
        self.status.setAlignment(Qt.AlignCenter)
        v.addWidget(self.status)

        self.theme_btn = QPushButton("Light Tema")
        self.theme_btn.clicked.connect(self.toggle_theme)
        v.addWidget(self.theme_btn, alignment=Qt.AlignRight)

        self.apply_lineedit_style()
        QTimer.singleShot(0, lambda: self.focus_placeholder.setFocus())

    def closeEvent(self, event):
        if self.total > 0:
            QMessageBox.warning(
                self,
                "Dikkat!",
                "Geri sayım devam ediyor! Önce işlemi İptal edin.",
                QMessageBox.Ok
            )
            event.ignore()
        else:
            event.accept()

    def toggle_theme(self):
        self.theme = "Light" if self.theme == "Dark" else "Dark"
        self.theme_btn.setText("Dark Tema" if self.theme == "Light" else "Light Tema")
        self.style()
        self.circle.update()
        self.apply_lineedit_style()

    def style(self):
        dark = self.theme == "Dark"
        self.setStyleSheet(f"""
            background: {'#0d1117' if dark else '#f9f9f9'};
            color: {'#f0f0f0' if dark else '#222'};
        """)
        self.btn_start.setStyleSheet("background:#27ae60; color:white; border-radius:16px;")
        self.btn_stop.setStyleSheet("background:#f39c12; color:white; border-radius:16px;")
        self.btn_cancel.setStyleSheet("background:#e74c3c; color:white; border-radius:16px;")
        self.btn_restart.setStyleSheet("background:#3498db; color:white; border-radius:16px;")

    def apply_lineedit_style(self):
        dark = self.theme == "Dark"
        bg = "rgba(255,255,255,50)" if dark else "rgba(0,0,0,30)"
        color = "#fff" if dark else "#000"
        border = "#3498db" if dark else "#2980b9"
        style = f"""
            QLineEdit {{
                background-color: {bg};
                border: 2px solid #ddd;
                border-radius: 20px;
                padding: 12px;
                font-size: 18px;
                color: {color};
                transition: all 0.2s;
            }}
            QLineEdit:hover {{
                border: 2px solid {border};
                background-color: rgba(255, 255, 255, 70);
            }}
            QLineEdit:focus {{
                border: 2px solid {border};
                background-color: rgba(255, 255, 255, 90);
            }}
        """
        self.h.setStyleSheet(style)
        self.m.setStyleSheet(style)

    def start(self, action="poweroff"):
        if self.total > 0:
            return
        try:
            h = int(self.h.text() or 0)
            m = int(self.m.text() or 0)
        except:
            QMessageBox.warning(self, "Hata", "Geçerli sayı girin!")
            return

        t = h*3600 + m*60

        if h==0 and m==0:
            QMessageBox.warning(self, "Hata", " Süre 0 Olamaz   !   ")
            return

        self.total = self.remain = t
        self.h.setEnabled(False)
        self.m.setEnabled(False)
        self.action = action
        self.is_paused = False
        self.update_ui()

        self.timer.start(1000)
        self.status.setText(f"Geri sayım devam ediyor… ({'Yeniden Başlat' if action=='reboot' else 'Kapat'})")
        self.btn_stop.setText("Beklet")

    def toggle_pause(self):
        if not self.timer.isActive() and self.remain > 0:
            self.timer.start(1000)
            self.is_paused = False
            self.status.setText("Geri sayım devam ediyor…")
            self.btn_stop.setText("Beklet")
        else:
            self.timer.stop()
            self.is_paused = True
            self.status.setText("Durduruldu")
            self.btn_stop.setText("Devam Et")

    def cancel(self):
        self.timer.stop()
        self.is_paused = False
        self.total = self.remain = 0
        self.action = "poweroff"
        self.h.setEnabled(True)
        self.m.setEnabled(True)
        self.h.clear()
        self.m.clear()
        self.status.setText("İptal edildi")
        self.btn_stop.setText("Beklet")
        self.circle.setPercent(0)
        self.time.setText("00:00:00")
        self.time.setStyleSheet("color: #ffffff;" if self.theme=="Dark" else "color:#000000;")

    def tick(self):
        self.remain -= 1
        if self.remain < 0:   # <=0 yerine <0 yaptık
            self.timer.stop()
            if self.action == "poweroff":
                self.status.setText("Bilgisayar kapanıyor…")
                os.system("systemctl poweroff")
            else:
                self.status.setText("Bilgisayar yeniden başlatılıyor…")
                os.system("systemctl reboot")
        else:
            self.update_ui()

    def update_ui(self):
        h = self.remain // 3600
        m = (self.remain % 3600) // 60
        s = self.remain % 60
        self.time.setText(f"{h:02d}:{m:02d}:{s:02d}")

        if self.total > 0:
            pct = (self.total - self.remain) / self.total * 100
            self.circle.setPercent(pct)

            if self.theme == "Light":
                yellow1 = QColor(255, 200, 0)
                yellow2 = QColor(255, 220, 50)
            else:
                yellow1 = QColor(255, 255, 0)
                yellow2 = QColor(255, 255, 100)

            if pct <= 25:
                t = pct / 25
                color = QColor(
                    int(yellow1.red()*(1-t) + yellow2.red()*t),
                    int(yellow1.green()*(1-t) + yellow2.green()*t),
                    int(yellow1.blue()*(1-t) + yellow2.blue()*t)
                )
            elif pct <= 50:
                t = (pct-25)/25
                color = QColor(int(180*(1-t)+128*t), int(240*(1-t)+255*t), 0)
            elif pct <= 75:
                t = (pct-50)/25
                color = QColor(int(0*(1-t)+0*t), int(128*(1-t)+200*t), 0)
            else:
                t = (pct-75)/25
                color = QColor(int(255*(1-t)+200*t), int(0*(1-t)+50*t), 0)

            self.time.setStyleSheet(f"color: rgb({color.red()},{color.green()},{color.blue()});")

def tek_örnek():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    try:
        s.bind('\0TurnOff_v22025')
    except:
        os.system("xdotool search --class TurnOff_v2 windowactivate 2>/dev/null")
        sys.exit(0)

if __name__ == "__main__":
    tek_örnek()
    app = QApplication(sys.argv)
    app.setApplicationName("TurnOff_v2")
    win = TurnOff_v2()
    win.show()
    sys.exit(app.exec_())

